using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
namespace RaceDay.MVC.Services;
public class RaceDayApiClient(HttpClient http)
{
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web) { PropertyNameCaseInsensitive = true };
    private HttpRequestMessage Create(HttpMethod method,string path,string? token)
    {
        var request = new HttpRequestMessage(method,path);
        if (!string.IsNullOrWhiteSpace(token)) request.Headers.Authorization = new AuthenticationHeaderValue("Bearer",token);
        return request;
    }
    public async Task<T?> GetAsync<T>(string path,string? token = null)
    {
        using var request = Create(HttpMethod.Get,path,token); using var response = await SendAsync(request);
        return await ReadAsync<T>(response);
    }
    public async Task<T?> PostAsync<TRequest,T>(string path,TRequest body,string? token = null)
    {
        using var request = Create(HttpMethod.Post,path,token); request.Content = JsonContent.Create(body);
        using var response = await SendAsync(request); return await ReadAsync<T>(response);
    }
    public async Task<T?> PutAsync<TRequest,T>(string path,TRequest body,string? token = null)
    {
        using var request = Create(HttpMethod.Put,path,token); request.Content = JsonContent.Create(body);
        using var response = await SendAsync(request); return await ReadAsync<T>(response);
    }
    public async Task<bool> DeleteAsync(string path,string? token = null)
    {
        using var request = Create(HttpMethod.Delete,path,token); using var response = await SendAsync(request);
        if (response.IsSuccessStatusCode) return true;
        throw await ApiException.FromResponse(response);
    }
    public async Task<T?> UploadAsync<T>(string path,IFormFile file,string token)
    {
        using var content = new MultipartFormDataContent();
        await using var stream = file.OpenReadStream();
        using var fileContent = new StreamContent(stream);
        fileContent.Headers.ContentType = new MediaTypeHeaderValue(file.ContentType);
        content.Add(fileContent,"file",Path.GetFileName(file.FileName));
        using var request = Create(HttpMethod.Post,path,token); request.Content = content;
        using var response = await SendAsync(request); return await ReadAsync<T>(response);
    }
    public async Task<(byte[] Bytes,string ContentType)> GetImageAsync(string container,string blobName)
    {
        using var request = new HttpRequestMessage(HttpMethod.Get,$"api/storage/images/{Uri.EscapeDataString(container)}/{Uri.EscapeDataString(blobName)}");
        using var response = await SendAsync(request);
        if (!response.IsSuccessStatusCode) throw await ApiException.FromResponse(response);
        return (await response.Content.ReadAsByteArrayAsync(),response.Content.Headers.ContentType?.ToString() ?? "application/octet-stream");
    }
    private async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request)
    {
        try { return await http.SendAsync(request); }
        catch (HttpRequestException) { throw new ApiException("The RaceDay API is unavailable. Check that the API is running and its address is correct.",HttpStatusCode.ServiceUnavailable); }
        catch (TaskCanceledException) { throw new ApiException("The RaceDay API request timed out. Please try again.",HttpStatusCode.GatewayTimeout); }
    }
    private static async Task<T?> ReadAsync<T>(HttpResponseMessage response)
    {
        if (!response.IsSuccessStatusCode) throw await ApiException.FromResponse(response);
        if (response.Content.Headers.ContentLength == 0) return default;
        return await response.Content.ReadFromJsonAsync<T>(JsonOptions);
    }
}
public class ApiException(string message,HttpStatusCode statusCode) : Exception(message)
{
    public HttpStatusCode StatusCode { get; } = statusCode;
    public static async Task<ApiException> FromResponse(HttpResponseMessage response)
    {
        var body = await response.Content.ReadAsStringAsync(); string message = "The request could not be completed.";
        try { using var json = JsonDocument.Parse(body); if (json.RootElement.TryGetProperty("message",out var value)) message = value.GetString() ?? message; else if (json.RootElement.TryGetProperty("title",out value)) message = value.GetString() ?? message; }
        catch { if (!string.IsNullOrWhiteSpace(body) && body.Length < 300) message = body; }
        return new ApiException(message,response.StatusCode);
    }
}
